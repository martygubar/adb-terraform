-- as moviestream
BEGIN
    admin.workshop.write('setup for app install as moviestream', 2);
    
    -- Set the name of the workspace in which the app needs to be installed
    apex_application_install.set_workspace('MOVIESTREAM');

    -- Setting the application id to 101
    apex_application_install.set_application_id(101);
    apex_application_install.generate_offset();

    -- Setting the Schema
    apex_application_install.set_schema('MOVIESTREAM');

    -- Setting application alias
    apex_application_install.set_application_alias('ASK-ORACLE');

    -- Set Auto Install Supporting Objects
    apex_application_install.set_auto_install_sup_obj( p_auto_install_sup_obj => true );

END;
/

@./f101.sql

